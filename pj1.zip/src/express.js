let app = require("./app");

app.listen(4000, () => {
    console.log("Executando Express na porta 4000");
})